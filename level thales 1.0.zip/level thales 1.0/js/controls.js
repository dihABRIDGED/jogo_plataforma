// Objeto `keys` para rastrear o estado das teclas pressionadas.
// Cada propriedade representa uma tecla e um booleano indica se está pressionada.
const keys = {
  // Controles do Jogador
  a: { pressed: false }, // Tecla 'a' para movimento para a esquerda
  d: { pressed: false }, // Tecla 'd' para movimento para a direita
  w: { pressed: false, canJump: true }, // Tecla 'w' para pular, adicionado canJump para controlar o pulo
  ArrowLeft: { pressed: false }, // Seta para a esquerda para movimento
  ArrowRight: { pressed: false }, // Seta para a direita para movimento
  ArrowUp: { pressed: false, canJump: true }, // Seta para cima para pular, adicionado canJump
  space: { pressed: false, canJump: true } // Tecla de espaço para pular (alternativa), adicionado canJump
};

// Adiciona um ouvinte de evento para quando uma tecla é pressionada (keydown)
window.addEventListener("keydown", (e) => {
  const key = e.key; // Obtém a tecla pressionada

  // Usa um switch para verificar qual tecla foi pressionada
  switch (key) {
    // Controles do Jogador
    case "a":
    case "A": // Permite 'a' ou 'A'
      keys.a.pressed = true; // Marca a tecla 'a' como pressionada
      if (player) player.lastKeyPressed = "a"; // Registra a última tecla pressionada para o player
      break;

    case "d":
    case "D": // Permite 'd' ou 'D'
      keys.d.pressed = true; // Marca a tecla 'd' como pressionada
      if (player) player.lastKeyPressed = "d"; // Registra a última tecla pressionada para o player
      break;

    case "w":
    case "W": // Permite 'w' ou 'W'
      // Só permite o pulo se a tecla 'w' estiver pressionada e o jogador puder pular (canJump é true)
      if (keys.w.canJump) {
        keys.w.pressed = true; // Marca a tecla 'w' como pressionada
        player.jump(); // Chama a função de pulo do jogador
        keys.w.canJump = false; // Impede pulos repetidos enquanto a tecla estiver pressionada
      }
      break;

    case "ArrowLeft":
      keys.ArrowLeft.pressed = true; // Marca a seta para a esquerda como pressionada
      if (player) player.lastKeyPressed = "ArrowLeft"; // Registra a última tecla pressionada para o player
      break;

    case "ArrowRight":
      keys.ArrowRight.pressed = true; // Marca a seta para a direita como pressionada
      if (player) player.lastKeyPressed = "ArrowRight"; // Registra a última tecla pressionada para o player
      break;

    case "ArrowUp":
      // Só permite o pulo se a tecla 'ArrowUp' estiver pressionada e o jogador puder pular
      if (keys.ArrowUp.canJump) {
        keys.ArrowUp.pressed = true; // Marca a seta para cima como pressionada
        player.jump(); // Chama a função de pulo do jogador
        keys.ArrowUp.canJump = false; // Impede pulos repetidos
      }
      break;

    case " ": // Tecla de espaço
      // Só permite o pulo se a tecla 'space' estiver pressionada e o jogador puder pular
      if (keys.space.canJump) {
        keys.space.pressed = true; // Marca a tecla de espaço como pressionada
        e.preventDefault(); // Previne o comportamento padrão do navegador (ex: scroll da página)
        player.jump(); // Chama a função de pulo do jogador
        keys.space.canJump = false; // Impede pulos repetidos
      }
      break;
  }
});

// Adiciona um ouvinte de evento para quando uma tecla é liberada (keyup)
window.addEventListener("keyup", (e) => {
  const key = e.key; // Obtém a tecla liberada

  // Usa um switch para verificar qual tecla foi liberada
  switch (key) {
    // Controles do Jogador
    case "a":
    case "A":
      keys.a.pressed = false; // Marca a tecla 'a' como não pressionada
      break;

    case "d":
    case "D":
      keys.d.pressed = false; // Marca a tecla 'd' como não pressionada
      break;

    case "w":
    case "W":
      keys.w.pressed = false; // Marca a tecla 'w' como não pressionada
      keys.w.canJump = true; // Permite o pulo novamente quando a tecla é liberada
      break;

    case "ArrowLeft":
      keys.ArrowLeft.pressed = false; // Marca a seta para a esquerda como não pressionada
      break;

    case "ArrowRight":
      keys.ArrowRight.pressed = false; // Marca a seta para a direita como não pressionada
      break;

    case "ArrowUp":
      keys.ArrowUp.pressed = false; // Marca a seta para cima como não pressionada
      keys.ArrowUp.canJump = true; // Permite o pulo novamente
      break;

    case " ":
      keys.space.pressed = false; // Marca a tecla de espaço como não pressionada
      keys.space.canJump = true; // Permite o pulo novamente
      break;
  }
});

// Função `handleControls` para aplicar os movimentos e ações do jogador com base nas teclas pressionadas
function handleControls() {
  // Retorna se o objeto player não existir (ainda não inicializado)
  if (!player) return;

  // Controles do Jogador
  player.velocity.x = 0; // Zera a velocidade horizontal do player a cada frame
  
  // Se a tecla 'a' ou seta esquerda estiver pressionada e foi a última tecla de direção, move para a esquerda
  if ((keys.a.pressed && player.lastKeyPressed === "a") || 
      (keys.ArrowLeft.pressed && player.lastKeyPressed === "ArrowLeft")) {
    player.velocity.x = -5; // Define velocidade negativa para mover para a esquerda
    player.facing = "left"; // Define a direção do player para a esquerda
  }
  
  // Se a tecla 'd' ou seta direita estiver pressionada e foi a última tecla de direção, move para a direita
  if ((keys.d.pressed && player.lastKeyPressed === "d") || 
      (keys.ArrowRight.pressed && player.lastKeyPressed === "ArrowRight")) {
    player.velocity.x = 5; // Define velocidade positiva para mover para a direita
    player.facing = "right"; // Define a direção do player para a direita
  }
  
  // A chamada para player.jump() foi movida para o evento keydown para evitar o 'quique'.
  // A lógica de controle de pulo agora está diretamente nos listeners de keydown e keyup.
}


