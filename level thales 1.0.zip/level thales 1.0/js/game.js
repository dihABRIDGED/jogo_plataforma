// Obtém o elemento canvas do HTML e seu contexto 2D para desenho
const canvas = document.querySelector('canvas');
const ctx = canvas.getContext('2d');

// Configurações do canvas
const canvasWidth = 1024;  // Largura do canvas
const canvasHeight = 576; // Altura do canvas
canvas.width = canvasWidth;   // Define a largura do canvas
canvas.height = canvasHeight; // Define a altura do canvas

// Variável para armazenar o tempo do frame anterior (usado para cálculo de FPS)
let prevTime = 0;

// Inicializa o jogador quando o jogo começa
initializePlayer();

// Inicia o loop principal de animação do jogo
animate();

// Loop principal de animação do jogo
function animate() {
  // Solicita ao navegador para chamar animate novamente no próximo frame
  window.requestAnimationFrame(animate);
  
  // Processa as entradas do usuário para controlar o jogador
  handleControls();
  
  // Limpa o canvas a cada frame com uma cor de fundo (céu azul)
  ctx.fillStyle = "#87CEEB";
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  
  // Desenha o chão do cenário
  drawGround();
  
  // Atualiza o estado do jogador (posição, gravidade, etc.)
  if (player) {
    player.update(); // Atualiza o jogador
  }
  
  // Calcula e exibe o FPS (frames por segundo) no console (opcional)
  let delta = (performance.now() - prevTime) / 1000;
  let fps = 1 / delta;
  prevTime = performance.now();
  
  // Descomente a linha abaixo se quiser ver o FPS no console
  // console.log("FPS:", Math.round(fps));
}

// Função para desenhar o chão do cenário
function drawGround() {
  // Desenha a base do chão (marrom)
  ctx.fillStyle = "#8B4513";
  ctx.fillRect(0, canvas.height - 50, canvas.width, 50);
  
  // Desenha a grama no topo do chão (verde)
  ctx.fillStyle = "#228B22";
  ctx.fillRect(0, canvas.height - 55, canvas.width, 5);
}

