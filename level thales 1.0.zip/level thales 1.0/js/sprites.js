// Define a constante de gravidade para o jogo
const gravity = 0.5;

// Classe base para todos os elementos visuais do jogo (sprites)
class Sprite {
  // Construtor da classe Sprite
  constructor({ position, velocity, dimensions, source, offset, sprites }) {
    // Posição do sprite no canvas
    this.position = position;
    // Velocidade do sprite (inicializada com 0 se não fornecida)
    this.velocity = velocity || { x: 0, y: 0 };
    // Largura do sprite (padrão 50 se não fornecida)
    this.width = dimensions?.width || 50;
    // Altura do sprite (padrão 50 se não fornecida)
    this.height = dimensions?.height || 50;

    // Escala do sprite (padrão 1)
    this.scale = 1;
    // Objeto Image para carregar a imagem do sprite
    this.image = new Image();
    // Define a fonte da imagem se fornecida
    if (source) {
      this.image.src = source;
    }

    // Offset para posicionamento da imagem (padrão 0,0)
    this.offset = offset || { x: 0, y: 0 };
    // Objeto contendo diferentes estados de sprites (ex: idle, run, jump)
    this.sprites = sprites || {
      idle: {
        src: this.image.src,
        totalSpriteFrames: 1,
        framesPerspriteFrame: 1,
      }
    };
    
    // Direção para a qual o sprite está virado (padrão 'right')
    this.facing = "right";
  }

  // Método para desenhar o sprite no canvas
  draw() {
    // Verifica se o contexto do canvas existe
    if (!ctx) return;
    
    // Desabilita o suavização de imagem para um visual pixelado
    ctx.imageSmoothingEnabled = false;

    // Desenha um retângulo colorido para representar o sprite (temporário, sem imagens)
    ctx.fillStyle = this.color || "white";
    ctx.fillRect(this.position.x, this.position.y, this.width, this.height);
  }

  // Método para atualizar o estado do sprite (apenas desenha por enquanto)
  update() {
    this.draw();
  }
}

// Classe Fighter que herda de Sprite, representando um personagem jogável
class Fighter extends Sprite {
  // Construtor da classe Fighter
  constructor({ position, velocity, dimensions, color }) {
    // Chama o construtor da classe pai (Sprite)
    super({ position, velocity, dimensions });

    // Velocidade do lutador (inicializada com 0 se não fornecida)
    this.velocity = velocity || { x: 0, y: 0 };
    // Largura e altura do lutador
    this.width = dimensions.width;
    this.height = dimensions.height;
    // Cor do lutador (padrão 'white')
    this.color = color || "white";
    
    // Última tecla pressionada para controle de direção
    this.lastKeyPressed = "";
    // Indica se o lutador está no chão
    this.onGround = false;
    // Contador de pulos para permitir pulo duplo (se desejado, atualmente 1)
    this.jumpCount = 0;
    // Altura máxima de pulo para controle de fluidez
    this.maxJumpHeight = 150; // Exemplo: 150 pixels
    // Posição Y inicial do pulo para calcular a altura
    this.initialJumpY = 0;
  }

  // Método para atualizar o estado do lutador a cada frame
  update() {
    // Atualiza a posição do lutador com base na velocidade
    this.position.x += this.velocity.x;
    this.position.y += this.velocity.y;

    // Aplica a gravidade
    this.velocity.y += gravity;

    // Verifica colisão com o chão
    // A colisão é detectada quando a parte inferior do jogador atinge ou ultrapassa a linha do chão.
    // A linha do chão é calculada como a altura total do canvas menos 50 pixels (altura do chão).
    if (this.position.y + this.height >= canvas.height - 50) {
      // Se colidiu com o chão, ajusta a posição Y para que o jogador fique exatamente sobre o chão.
      // Isso evita que o jogador afunde no chão ou flutue acima dele.
      this.position.y = canvas.height - 50 - this.height;
      // Zera a velocidade vertical para parar a queda ou o pulo ao tocar o chão.
      this.velocity.y = 0;
      // Define onGround como true, indicando que o jogador está no chão.
      this.onGround = true;
      // Reseta o contador de pulos, permitindo que o jogador pule novamente.
      this.jumpCount = 0;
    } else {
      // Se não estiver colidindo com o chão, define onGround como false.
      this.onGround = false;
    }

    // Limita o movimento horizontal para que o lutador não saia da tela
    // Se o jogador tentar ir para a esquerda além da borda do canvas, sua posição X é ajustada para 0.
    if (this.position.x < 0) {
      this.position.x = 0;
    }
    // Se o jogador tentar ir para a direita além da borda do canvas, sua posição X é ajustada
    // para a largura do canvas menos a largura do jogador, mantendo-o dentro dos limites.
    if (this.position.x + this.width > canvas.width) {
      this.position.x = canvas.width - this.width;
    }

    // Desenha o lutador no canvas
    this.draw();
  }

  // Método para fazer o lutador pular
  jump() {
    // Permite o pulo apenas se o jogador estiver no chão (onGround é true)
    // ou se o jumpCount for menor que 1 (para permitir um pulo duplo, se implementado).
    // Atualmente, jumpCount é resetado para 0 ao tocar o chão, então só permite um pulo.
    if (this.onGround || this.jumpCount < 1) { // Alterado para permitir um pulo mais fluido
      // Define a velocidade vertical negativa para iniciar o pulo.
      // O valor -12 é um bom ponto de partida para a altura do pulo.
      this.velocity.y = -12;
      // Incrementa o contador de pulos.
      this.jumpCount++;
      // Registra a posição Y inicial do pulo para controle de altura (se necessário).
      this.initialJumpY = this.position.y;
    }
  }
}

// Declaração da variável para o jogador
let player;

// Função para inicializar o jogador
function initializePlayer() {
  player = new Fighter({
    position: { x: 100, y: 0 },
    dimensions: { width: 50, height: 100 },
    velocity: { x: 0, y: 0 },
    color: "#4CAF50" // Cor do jogador (verde)
  });
}



